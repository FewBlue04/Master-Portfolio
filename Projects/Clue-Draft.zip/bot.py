"""
Clue Bot Player — uses KnowledgeBase for optimal play.
"""

from engine.knowledge_base import KnowledgeBase
from engine.cards import SUSPECTS, WEAPONS, ROOMS, CARD_TYPE


class BotPlayer:
    def __init__(self, name, cards, all_players, num_cards_per_player):
        self.name = name
        self.cards = list(cards)
        self.current_room = None
        self.eliminated = False

        self.kb = KnowledgeBase(
            player_names=all_players,
            my_name=name,
            my_cards=self.cards,
            num_cards_per_player=num_cards_per_player,
        )

    # ------------------------------------------------------------------
    # Observation callbacks (called by game engine)
    # ------------------------------------------------------------------

    def observe_no_show(self, player, suspect, weapon, room):
        """Another player passed — they have none of the three cards."""
        self.kb.observe_no_show(player, suspect, weapon, room)

    def observe_showed_card_to_other(self, shower, suspect, weapon, room):
        """
        `shower` showed a card to another player (not us).
        We know shower has at least one of suspect/weapon/room.
        """
        self.kb.observe_showed_unknown(shower, suspect, weapon, room)

    def observe_showed_card_to_me(self, shower, card):
        """Another player showed THIS specific card to us."""
        self.kb.observe_hand(shower, card)

    # ------------------------------------------------------------------
    # Decision methods
    # ------------------------------------------------------------------

    def choose_suggestion(self):
        """
        Returns (suspect, weapon, room) — the best suggestion to make.
        Uses KB scoring to maximize expected information gain.
        """
        s, w, r, score = self.kb.best_suggestion(available_room=self.current_room)
        return s, w, r

    def choose_accusation(self):
        """
        Returns (suspect, weapon, room) if we're confident enough to accuse,
        else None.
        """
        sol_s, sol_w, sol_r = self.kb.get_solution()
        if sol_s and sol_w and sol_r:
            return sol_s, sol_w, sol_r
        return None

    def should_accuse(self):
        return self.kb.is_solved()

    def pick_card_to_show(self, suspect, weapon, room):
        """
        When asked to show a card, pick the one that reveals least info.
        Prefer showing cards that are already known by the asker if possible,
        otherwise show the one held by the most other players.
        """
        can_show = [c for c in (suspect, weapon, room) if c in self.cards]
        if not can_show:
            return None

        # Prefer card that gives least new info (already seen or common)
        # Simple heuristic: show the one whose type is already solved in KB
        sol_s, sol_w, sol_r = self.kb.get_solution()
        for card in can_show:
            ctype = CARD_TYPE[card]
            if ctype == "suspect" and sol_s:
                return card
            if ctype == "weapon" and sol_w:
                return card
            if ctype == "room" and sol_r:
                return card

        # Fallback: show the first one
        return can_show[0]

    def get_knowledge_summary(self):
        """Returns a human-readable summary for UI display."""
        sol_s, sol_w, sol_r = self.kb.get_solution()
        lines = []
        if sol_s:
            lines.append(f"✓ Murderer: {sol_s}")
        else:
            lines.append("? Murderer: unknown")
        if sol_w:
            lines.append(f"✓ Weapon: {sol_w}")
        else:
            lines.append("? Weapon: unknown")
        if sol_r:
            lines.append(f"✓ Room: {sol_r}")
        else:
            lines.append("? Room: unknown")
        return "\n".join(lines)
