"""
Knowledge Base for Clue AI Bot.

Uses propositional logic and constraint propagation to track:
- Which cards each player definitely HAS
- Which cards each player definitely DOES NOT have
- Clause constraints: "at least one of {A, B, C} is held by player P"

The KB reasons over these facts using:
1. Direct elimination (when someone shows/doesn't show a card)
2. Clause resolution (when all but one card in a clause is eliminated)
3. Cross-player inference (if a card is confirmed held by P, no one else has it)
4. Information gain scoring (entropy-based) for optimal suggestion selection
"""

from itertools import combinations
from collections import defaultdict
from engine.cards import ALL_CARDS, SUSPECTS, WEAPONS, ROOMS, CARD_TYPE


class KnowledgeBase:
    def __init__(self, player_names, my_name, my_cards, num_cards_per_player):
        """
        player_names: list of all player names in turn order
        my_name: the bot's own name
        my_cards: list of cards the bot holds
        num_cards_per_player: dict {player_name: num_cards}
        """
        self.player_names = player_names
        self.my_name = my_name
        self.num_cards_per_player = num_cards_per_player

        # Tri-state knowledge per (player, card):
        #   True  = player definitely HAS this card
        #   False = player definitely does NOT have this card
        #   None  = unknown
        self.has_card = {}  # (player, card) -> True/False/None

        # Clauses: list of (player, frozenset_of_cards)
        # meaning: player has AT LEAST ONE of these cards
        self.clauses = []

        # Confirmed solution candidates
        self._solution_suspect = None
        self._solution_weapon = None
        self._solution_room = None

        # Initialize
        self._init_knowledge(my_cards)

    def _init_knowledge(self, my_cards):
        """Set up initial state from own hand."""
        for player in self.player_names:
            for card in ALL_CARDS:
                self.has_card[(player, card)] = None

        # Bot knows its own cards
        for card in my_cards:
            self._set_has(self.my_name, card, True)

        # Bot doesn't have cards not in hand
        for card in ALL_CARDS:
            if card not in my_cards:
                self._set_has(self.my_name, card, False)

    # ------------------------------------------------------------------
    # Core setters with propagation
    # ------------------------------------------------------------------

    def _set_has(self, player, card, value):
        """Set has_card and trigger propagation if value changed."""
        key = (player, card)
        if self.has_card.get(key) == value:
            return  # no change
        self.has_card[key] = value
        self._propagate()

    def _propagate(self):
        """Run constraint propagation until fixpoint."""
        changed = True
        while changed:
            changed = False
            changed |= self._propagate_card_uniqueness()
            changed |= self._propagate_clauses()
            changed |= self._propagate_player_counts()
            changed |= self._infer_solution()

    def _propagate_card_uniqueness(self):
        """If player P has card C, no other player has C."""
        changed = False
        for card in ALL_CARDS:
            # Find who is confirmed to have this card
            owner = None
            for player in self.player_names:
                if self.has_card.get((player, card)) is True:
                    owner = player
                    break
            if owner:
                for player in self.player_names:
                    if player != owner and self.has_card.get((player, card)) is not False:
                        self.has_card[(player, card)] = False
                        changed = True
        return changed

    def _propagate_clauses(self):
        """
        For each clause (player, cards):
          - Remove cards we know player doesn't have
          - If only one card remains, player must have it
          - If player has any card in clause, clause is satisfied → remove
        """
        changed = False
        new_clauses = []
        for (player, cards) in self.clauses:
            # Check if satisfied
            satisfied = any(
                self.has_card.get((player, c)) is True for c in cards
            )
            if satisfied:
                changed = True
                continue  # drop clause

            # Remove eliminated cards
            remaining = frozenset(
                c for c in cards
                if self.has_card.get((player, c)) is not False
            )

            if len(remaining) == 0:
                # Contradiction — shouldn't happen in valid game
                new_clauses.append((player, remaining))
                continue

            if len(remaining) == 1:
                # Must have this card
                (card,) = remaining
                if self.has_card.get((player, card)) is not True:
                    self.has_card[(player, card)] = True
                    changed = True
                # Clause is now resolved, drop it
                changed = True
                continue

            if remaining != cards:
                changed = True

            new_clauses.append((player, remaining))

        self.clauses = new_clauses
        return changed

    def _propagate_player_counts(self):
        """
        If a player has exactly N unknowns and we know they hold exactly N more cards,
        all those unknowns must be True.
        Conversely, if they've confirmed all their cards, remaining unknowns are False.
        """
        changed = False
        for player in self.player_names:
            if player == self.my_name:
                continue
            total = self.num_cards_per_player.get(player, 0)
            confirmed = sum(
                1 for c in ALL_CARDS
                if self.has_card.get((player, c)) is True
            )
            unknowns = [
                c for c in ALL_CARDS
                if self.has_card.get((player, c)) is None
            ]
            needed = total - confirmed

            if needed == len(unknowns) and needed > 0:
                # All unknowns must be True
                for c in unknowns:
                    self.has_card[(player, c)] = True
                    changed = True
            elif needed == 0 and unknowns:
                # No more cards to assign — all unknowns are False
                for c in unknowns:
                    self.has_card[(player, c)] = False
                    changed = True

        return changed

    def _infer_solution(self):
        """
        A card is in the solution envelope if NO player has it.
        """
        changed = False
        for card in ALL_CARDS:
            all_false = all(
                self.has_card.get((p, card)) is False
                for p in self.player_names
            )
            if all_false:
                # This card is in the envelope
                ctype = CARD_TYPE[card]
                if ctype == "suspect" and self._solution_suspect != card:
                    self._solution_suspect = card
                    changed = True
                elif ctype == "weapon" and self._solution_weapon != card:
                    self._solution_weapon = card
                    changed = True
                elif ctype == "room" and self._solution_room != card:
                    self._solution_room = card
                    changed = True
        return changed

    # ------------------------------------------------------------------
    # Public observation methods
    # ------------------------------------------------------------------

    def observe_hand(self, player, card):
        """We directly see that `player` has `card` (e.g. they showed it to us)."""
        self._set_has(player, card, True)

    def observe_no_show(self, player, suspect, weapon, room):
        """
        `player` could not show any of {suspect, weapon, room}.
        → player does NOT have any of these cards.
        """
        for card in (suspect, weapon, room):
            self._set_has(player, card, False)

    def observe_showed_unknown(self, player, suspect, weapon, room):
        """
        `player` showed a card to someone else but we don't know which.
        → player has AT LEAST ONE of {suspect, weapon, room}.
        """
        cards = frozenset([suspect, weapon, room])
        # Only add clause if not already subsumed
        already = any(
            p == player and existing_cards.issubset(cards)
            for (p, existing_cards) in self.clauses
        )
        if not already:
            # Remove any existing supersets (weaker clauses)
            self.clauses = [
                (p, cs) for (p, cs) in self.clauses
                if not (p == player and cards.issubset(cs))
            ]
            self.clauses.append((player, cards))
            self._propagate()

    # ------------------------------------------------------------------
    # Solution queries
    # ------------------------------------------------------------------

    def get_solution(self):
        """Returns (suspect, weapon, room) if fully solved, else None fields."""
        return (self._solution_suspect, self._solution_weapon, self._solution_room)

    def is_solved(self):
        s, w, r = self.get_solution()
        return s is not None and w is not None and r is not None

    def card_status(self, card):
        """
        Returns one of:
          'mine'     - bot holds it
          'held'     - confirmed held by another player (not solution)
          'envelope' - confirmed in solution envelope
          'unknown'  - uncertain
        """
        if self.has_card.get((self.my_name, card)) is True:
            return 'mine'
        all_false = all(
            self.has_card.get((p, card)) is False
            for p in self.player_names
        )
        if all_false:
            return 'envelope'
        any_true = any(
            self.has_card.get((p, card)) is True
            for p in self.player_names if p != self.my_name
        )
        if any_true:
            return 'held'
        return 'unknown'

    # ------------------------------------------------------------------
    # Optimal suggestion selection (information gain / entropy)
    # ------------------------------------------------------------------

    def score_suggestion(self, suspect, weapon, room):
        """
        Score a suggestion triple by expected information gain.
        Higher = better question to ask.

        Strategy:
        - Prioritize triples containing unknown/envelope cards
        - Penalize triples where we already know all three cards
        - Reward triples that maximally disambiguate the solution
        """
        cards = [suspect, weapon, room]
        statuses = [self.card_status(c) for c in cards]

        # If we know the solution for a category, don't vary it
        score = 0

        envelope_count = statuses.count('envelope')
        unknown_count = statuses.count('unknown')
        held_count = statuses.count('held')
        mine_count = statuses.count('mine')

        # Maximum value: all three are unknown/envelope (pure discovery)
        score += unknown_count * 10
        score += envelope_count * 15   # envelope cards confirm solution
        score -= mine_count * 5        # no new info from our own cards
        score -= held_count * 3        # less info (someone shows it, not useful for envelope)

        # Bonus: if this triple contains a specific solution candidate
        sol_s, sol_w, sol_r = self.get_solution()
        if sol_s == suspect:
            score += 5
        if sol_w == weapon:
            score += 5
        if sol_r == room:
            score += 5

        # Bonus: prefer cards that have many None entries across players
        # (more uncertainty = more to learn)
        for card in cards:
            none_count = sum(
                1 for p in self.player_names
                if self.has_card.get((p, card)) is None
            )
            score += none_count * 2

        return score

    def best_suggestion(self, available_room=None):
        """
        Find the best (suspect, weapon, room) suggestion to make.
        If available_room is specified, fix the room (current location).
        Returns (suspect, weapon, room, score).
        """
        best_score = -999
        best = None

        # Determine room choices
        rooms_to_try = [available_room] if available_room else ROOMS

        # Focus suspects/weapons: prefer unknowns/envelope candidates
        def rank_cards(card_list):
            return sorted(card_list, key=lambda c: (
                -(self.card_status(c) == 'unknown'),
                -(self.card_status(c) == 'envelope'),
                self.card_status(c) == 'mine',
            ))

        ranked_suspects = rank_cards(SUSPECTS)
        ranked_weapons = rank_cards(WEAPONS)
        ranked_rooms = rank_cards(rooms_to_try)

        # Evaluate top combinations (prune search space)
        for s in ranked_suspects[:6]:
            for w in ranked_weapons[:6]:
                for r in ranked_rooms:
                    score = self.score_suggestion(s, w, r)
                    if score > best_score:
                        best_score = score
                        best = (s, w, r)

        return best[0], best[1], best[2], best_score

    # ------------------------------------------------------------------
    # Debug / display helpers
    # ------------------------------------------------------------------

    def get_notebook(self):
        """
        Returns a structured dict for UI display:
        { card: { player: True/False/None, ... } }
        """
        notebook = {}
        for card in ALL_CARDS:
            notebook[card] = {}
            for player in self.player_names:
                notebook[card][player] = self.has_card.get((player, card))
        return notebook

    def get_envelope_probabilities(self):
        """
        Rough probability that each card is in the envelope.
        Based on: 0 players confirmed to have it + proportion of unknowns.
        """
        probs = {}
        for card in ALL_CARDS:
            status = self.card_status(card)
            if status == 'envelope':
                probs[card] = 1.0
            elif status in ('mine', 'held'):
                probs[card] = 0.0
            else:
                # Count how many players might have it
                none_count = sum(
                    1 for p in self.player_names
                    if self.has_card.get((p, card)) is None
                )
                total = len(self.player_names)
                # Probability it slipped through everyone = decreases with more players
                probs[card] = round(1.0 / (none_count + 1), 3) if none_count < total else 0.2
        return probs
